//
//  DetailsViewController.h
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsViewController : UIViewController<UIApplicationDelegate>

@property(nonatomic,weak) IBOutlet UIImageView *selectedImageView;
@property(nonatomic,copy) NSString *selectedImageURL;
@property(nonatomic,copy) NSString *selectedUser;

@end
