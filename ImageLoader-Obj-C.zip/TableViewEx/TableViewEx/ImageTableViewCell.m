//
//  ImageTableViewCell.m
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import "ImageTableViewCell.h"
#import "Constants.h"
#import "AppDelegate.h"
@implementation ImageTableViewCell
@synthesize imageView;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)loadPhotoDetails:(NSDictionary *)imageInfo{
    self.titleLabel.text = [imageInfo valueForKey:@"name"];
    AppDelegate *delegate = (AppDelegate *) [UIApplication sharedApplication].delegate;
    [delegate downloadedImageForURL:[imageInfo valueForKey:kImageKey] with:^(UIImage *downloadImage, NSError *error) {
        if (error) {
            NSLog(@"Oops error: %@",error.localizedDescription);
        } else {
            self.imageView.image = downloadImage;
        }
    }];
}

@end
