//
//  HomeViewController.h
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageTableViewCell.h"
#import "AppDelegate.h"

@interface HomeViewController : UITableViewController<UIApplicationDelegate, UISearchBarDelegate>

@property(nonatomic,weak)IBOutlet UISegmentedControl *sortSegment;
@property(nonatomic,weak)IBOutlet UISearchBar *searchBarText;

-(IBAction)sortBy:(UISegmentedControl *)sender;
@end
