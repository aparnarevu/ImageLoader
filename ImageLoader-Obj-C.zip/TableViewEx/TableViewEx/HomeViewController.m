//
//  HomeViewController.m
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import "HomeViewController.h"
#import "Constants.h"

#import "DetailsViewController.h"
@interface HomeViewController ()
{
    NSArray *jsonImagesList;
    UIStoryboard *storyboard;
    id appDelegate;
}
@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Objective-C";
    self.sortSegment.selectedSegmentIndex = 0;
    storyboard =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    jsonImagesList = [appDelegate jsonData];
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return jsonImagesList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ImageTableViewCell *cell = (ImageTableViewCell *) [tableView dequeueReusableCellWithIdentifier:@"CellIdentifier" forIndexPath:indexPath];
    [cell loadPhotoDetails:[jsonImagesList objectAtIndex:indexPath.row]];
    
    if (indexPath.row > jsonImagesList.count-1) {
        cell.separatorInset = UIEdgeInsetsMake(0.f, cell.bounds.size.width, 0.f, 0.f);
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    DetailsViewController *detailsView = [storyboard instantiateViewControllerWithIdentifier:@"DetailsViewController"];
    NSDictionary *dict = [jsonImagesList objectAtIndex:indexPath.row];
    detailsView.selectedImageURL = [dict valueForKey:kImageKey];
    detailsView.selectedUser = [dict valueForKey:@"name"];

    [self.navigationController pushViewController:detailsView animated:YES];
}


#pragma mark - Utility Methods

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText;
// called when text changes (including clear)
{
    if(searchBar.text.length > 0){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name CONTAINS %@", searchBar.text ];
        jsonImagesList  = [jsonImagesList filteredArrayUsingPredicate:predicate];
    }else {
        [searchBar resignFirstResponder];
        jsonImagesList = [appDelegate jsonData];
    }
    [self.tableView reloadData];

}

- (void)searchBarTextDidEndEditing:(UISearchBar *)aSearchBar {
    [aSearchBar resignFirstResponder];
}

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text NS_AVAILABLE_IOS(3_0); // called before text changes
{
    if([text isEqualToString:@"\n"]) {
        [searchBar resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}
-(IBAction)sortBy:(UISegmentedControl *)sender
{
    NSSortDescriptor *nameDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name"  ascending:
                                        (sender.selectedSegmentIndex == 0) ? YES : NO];
    
    NSArray *sortDescriptors = [NSArray arrayWithObject:nameDescriptor];
    jsonImagesList = [jsonImagesList sortedArrayUsingDescriptors:sortDescriptors];
    [self.tableView reloadData];

}
@end
