//
//  Constants.h
//  SampleAPI
//
//  Created by hcl on 7/31/16.
//  Copyright © 2016 OrangePeople. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject

extern NSString *const kLoadingImagesAPI;
extern NSString *const kMainKey;
extern NSString *const kTitleKey;
extern NSString *const kImageKey;

@end
