//
//  DetailsViewController.m
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import "DetailsViewController.h"
#import "AppDelegate.h"
@interface DetailsViewController ()

@end

@implementation DetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.selectedUser;
    // Do any additional setup after loading the view.
    
    AppDelegate *delegate = (AppDelegate *) [UIApplication sharedApplication].delegate;
    [delegate downloadedImageForURL:self.selectedImageURL with:^(UIImage *downloadImage, NSError *error) {
        if (error) {
            NSLog(@"Oops error: %@",error.localizedDescription);
        } else {
            self.selectedImageView.image = downloadImage;
        }
    }];

}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
