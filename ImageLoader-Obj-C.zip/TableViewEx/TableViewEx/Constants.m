//
//  Constants.m
//  SampleAPI
//
//  Created by hcl on 7/31/16.
//  Copyright © 2016 OrangePeople. All rights reserved.
//

#import "Constants.h"

@implementation Constants

NSString *const kLoadingImagesAPI = @"http://microblogging.wingnity.com/JSONParsingTutorial/jsonActors";
NSString *const kMainKey = @"actors";
NSString *const kNameKey = @"name";
NSString *const kImageKey = @"image";


@end
