//
//  AppDelegate.h
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSMutableArray *jsonData;
typedef void (^Completion)(UIImage* downloadImage, NSError *error);

- (void)downloadedImageForURL:(NSString *)thumbnailImageURL with:(Completion)block;

@end

