//
//  ImageTableViewCell.h
//  TableViewEx
//
//  Created by Aparna Revu on 1/18/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface ImageTableViewCell : UITableViewCell<UIApplicationDelegate>

@property(nonatomic,weak) IBOutlet UIImageView *imageView;
@property(nonatomic,weak) IBOutlet UILabel *titleLabel;

-(void)loadPhotoDetails:(NSDictionary *)imageInfo;
@end

