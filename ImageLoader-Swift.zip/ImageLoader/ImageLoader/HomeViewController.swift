//
//  HomeViewController.swift
//  ImageLoader
//
//  Created by Aparna Revu on 1/20/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

import UIKit

class HomeViewController: UITableViewController {

    @IBOutlet weak var sortSegment: UISegmentedControl!
    @IBOutlet weak var searchBarText: UISearchBar!

    var jsonImagesList = [Any]()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Swift"
        self.sortSegment.selectedSegmentIndex = 0
        let delegate = UIApplication.shared.delegate as! AppDelegate

        jsonImagesList = delegate.jsonData
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return jsonImagesList.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ImageTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath) as? ImageTableViewCell)

        cell?.loadPhotoDetails(jsonImagesList[indexPath.row] as! [AnyHashable : Any])


        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsView = storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        
        var dict: [AnyHashable: Any] = jsonImagesList[indexPath.row] as! [AnyHashable : Any]
        detailsView.selectedImageURL = dict["image"] as! String
        detailsView.selectedUser = dict["name"] as! String
        self.navigationController?.pushViewController(detailsView, animated: true)
    }


    
    
    @IBAction func sort(by sender: UISegmentedControl) {
        
        if(sender.selectedSegmentIndex == 0) {
           jsonImagesList = jsonImagesList.sorted{
                
                (($0 as! Dictionary<String, AnyObject>)["name"] as? String)! < (($1 as! Dictionary<String, AnyObject>)["name"] as? String)!
            }

        }else{
            jsonImagesList = jsonImagesList.sorted{
                (($0 as! Dictionary<String, AnyObject>)["name"] as? String)! > (($1 as! Dictionary<String, AnyObject>)["name"] as? String)!
            }

        }
        self.tableView.reloadData()
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // called when text changes (including clear)
        let len = searchBar.text!.characters.count

        if len > 0 {
            let resultPredicate = NSPredicate(format: "name contains[c] %@", searchBar.text!)

            jsonImagesList = jsonImagesList.filter { resultPredicate.evaluate(with: $0) };
        }
        else {
            searchBar.resignFirstResponder()
            let delegate = UIApplication.shared.delegate as! AppDelegate

            jsonImagesList = delegate.jsonData
        }
        self.tableView.reloadData()
    }
    
    func searchBarTextDidEndEditing(_ aSearchBar: UISearchBar) {
        aSearchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        // called before text changes
        if (text == "\n") {
            searchBar.resignFirstResponder()
            return false
        }
        return true
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }


}
