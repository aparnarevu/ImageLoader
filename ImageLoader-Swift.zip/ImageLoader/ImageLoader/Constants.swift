//
//  Constants.swift
//  ImageLoader
//
//  Created by Aparna Revu on 1/20/17.
//  Copyright © 2017 Aparna Revu. All rights reserved.
//

import Foundation

class Constants: NSObject {
    let kTitleKey: String = ""
    
    let kLoadingImagesAPI: String = "http://microblogging.wingnity.com/JSONParsingTutorial/jsonActors"
    let kMainKey: String = "actors"
    let kNameKey: String = "name"
    let kImageKey: String = "image"
}
